import React, { useState } from 'react';
import './Login.css';

const Login = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState(''); // for registration

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isLogin) {
      // Handle login logic here, e.g., API call
      console.log('Email:', email, 'Password:', password);
    } else {
      // Handle registration logic here, e.g., API call
      console.log('Name:', name, 'Email:', email, 'Password:', password);
    }
  };

  return (
    <div className="container mt-4">
      <form onSubmit={handleSubmit} className='col-sm-12 col-md-6 mx-auto form-container'>
        <h1 className="login-heading">{isLogin ? 'Login' : 'Register'}</h1>

        {isLogin ? null : (
          <div className="form-group">
            {/* <label htmlFor="name" className='pt-4'>Name</label> */}
            <input
              type="text"
              className="form-control mt-4"
              id="name"
              placeholder="Enter Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
        )}

        <div className="form-group">
          {/* <label htmlFor="email" className='pt-4'>Email</label> */}
          <input
            type="email"
            className="form-control mt-4"
            id="email"
            placeholder="Enter email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div className="form-group">
          {/* <label htmlFor="password" className='pt-4'>Password</label> */}
          <input
            type="password"
            className="form-control mt-4"
            id="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary mt-4">
          {isLogin ? 'Login' : 'Register'}
        </button>
        <p className="mt-3">
          {isLogin ? "Don't have an account? " : "Already have an account? "}
          <span onClick={() => setIsLogin(!isLogin)} className="login-link">
            {isLogin ? 'Register' : 'Login'}
          </span>
        </p>
      </form>
    </div>
  );
};

export default Login;